#include "Harvester.hpp"

using namespace std;

void Harvester::turn(vector<vector<Insect*> > & board, int x) {
	// for(int j = 0; j < board[x].size(); j++) {
	// 	if(board)
	// }
}


Harvester::Harvester() {
	this->armor = 1;
	this->foodCost = 2;
	this->name = "Harvester";
}